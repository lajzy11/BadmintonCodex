import type { MemberFilters } from './MemberFilterBar'
import type { ActivityWorkspace } from './activityWorkspaceApi'

const labels: Record<string, string> = { cash: '現金', line_pay: 'LINE Pay', transfer: '轉帳', voucher: '球券', other: '其他' }
const time = (value: string | number) => new Intl.DateTimeFormat('zh-TW', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Taipei' }).format(new Date(value))

export function OverviewInsights({ workspace, onOpenMembers }: { workspace: ActivityWorkspace; onOpenMembers: (filters?: Partial<MemberFilters>) => void }) {
  const active = workspace.members.filter((member) => member.registration_status === 'active')
  const planStats = workspace.plans.map((plan) => {
    const members = active.filter((member) => member.plan_id === plan.id)
    return { plan, members: members.length, checkedIn: members.filter((member) => member.checkin_status === 'checked_in').length, collected: members.filter((member) => member.payment_status === 'paid').length * (plan.amount ?? 0) }
  })
  const payments = Object.entries(active.filter((member) => member.payment_status === 'paid' && member.payment_method).reduce<Record<string, number>>((result, member) => {
    const amount = workspace.plans.find((plan) => plan.id === member.plan_id)?.amount ?? 0
    result[member.payment_method!] = (result[member.payment_method!] ?? 0) + amount
    return result
  }, {}))
  const started = active.filter((member) => Date.now() >= new Date(workspace.plans.find((plan) => plan.id === member.plan_id)?.start_at ?? '2999-01-01').getTime())
  const pendingCheckin = started.filter((member) => member.checkin_status === 'not_arrived').length
  const pendingPayment = workspace.activity.finance_enabled ? started.filter((member) => member.payment_status === 'unpaid' && member.no_show_status !== 'waived').length : 0
  const unpaidMembers = active.filter((member) => member.payment_status === 'unpaid' && member.no_show_status !== 'waived').length
  const segments: Array<{ start: number; end: number; count: number }> = []

  if (workspace.plans.length > 1) {
    const starts = workspace.plans.map((plan) => new Date(plan.start_at).getTime())
    const ends = workspace.plans.map((plan) => new Date(plan.end_at).getTime())
    for (let start = Math.min(...starts); start < Math.max(...ends); start += 1_800_000) {
      const end = Math.min(start + 1_800_000, Math.max(...ends))
      const count = active.filter((member) => { const plan = workspace.plans.find((item) => item.id === member.plan_id); return plan && new Date(plan.start_at).getTime() <= start && new Date(plan.end_at).getTime() >= end }).length
      const previous = segments.at(-1)
      if (previous?.count === count) previous.end = end
      else segments.push({ start, end, count })
    }
  }

  return <>
    <section className="workspace-section">
      <div className="section-heading"><div><h2>方案統計</h2><p className="muted">點擊人數即可查看對應名單</p></div></div>
      <div className={`plan-stat-table${workspace.activity.finance_enabled ? '' : ' finance-off'}`}>
        <div className="plan-stat-row head"><span>方案</span><span>時間</span><span>名單</span><span>報到</span>{workspace.activity.finance_enabled && <><span>金額</span><span>已收</span></>}</div>
        {planStats.map(({ plan, members, checkedIn, collected }) => <div className="plan-stat-row" key={plan.id}><strong>方案 {plan.code}</strong><span>{time(plan.start_at)}–{time(plan.end_at)}</span><button onClick={() => onOpenMembers({ plan: plan.id })}>{members} 人</button><button onClick={() => onOpenMembers({ plan: plan.id, checkin: 'checked_in' })}>{checkedIn} 人</button>{workspace.activity.finance_enabled && <><span>${plan.amount ?? 0}</span><button onClick={() => onOpenMembers({ plan: plan.id, payment: 'paid' })}>${collected}</button></>}</div>)}
      </div>
      {workspace.activity.finance_enabled && <div className="overview-finance-detail"><dl><div><dt>待收金額</dt><dd>${Math.max(0, workspace.stats.expected_amount - workspace.stats.collected_amount)}</dd></div><div><dt>待收人數</dt><dd><button onClick={() => onOpenMembers({ payment: 'unpaid' })}>{unpaidMembers} 人</button></dd></div></dl><div><strong>付款方式統計</strong>{payments.length ? payments.map(([method, amount]) => <span key={method}>{labels[method] ?? method}{method === 'line_pay' ? '（Demo）' : ''}：${amount}</span>) : <span className="muted">尚無已確認收款</span>}</div></div>}
    </section>
    {segments.length > 0 && <section className="workspace-section"><div className="section-heading"><div><h2>各時段有效人數</h2><p className="muted">依方案時間每 30 分鐘計算；不推估場地需求</p></div></div><div className="time-segment-list">{segments.map((segment) => <div key={segment.start}><span>{time(segment.start)}–{time(segment.end)}</span><strong>{segment.count} 人</strong></div>)}</div></section>}
    {(pendingCheckin > 0 || pendingPayment > 0) && <section className="workspace-section attention-section"><div className="section-heading"><div><h2>待處理事項</h2><p className="muted">只顯示所屬方案已開始的項目</p></div></div>{pendingCheckin > 0 && <button onClick={() => onOpenMembers({ checkin: 'not_arrived' })}>尚未報到 <strong>{pendingCheckin} 人</strong></button>}{pendingPayment > 0 && <button onClick={() => onOpenMembers({ payment: 'unpaid' })}>尚未付款 <strong>{pendingPayment} 人</strong></button>}</section>}
  </>
}
