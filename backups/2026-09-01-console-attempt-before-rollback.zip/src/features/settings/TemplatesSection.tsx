import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import type { ActivityTemplate } from '../activities/activitySourcesApi'
import { useActivityTemplates, useManageTemplate } from './settingsApi'

const assignLabels: Record<string, string> = { system_assign: '系統排點', manual_assign: '人工排點', free_play: '自由上場' }

export function TemplatesSection({ onMessage }: { onMessage: (message: string) => void }) {
  const navigate = useNavigate()
  const templates = useActivityTemplates()
  const manage = useManageTemplate()
  const items = templates.data ?? []
  const [rename, setRename] = useState<ActivityTemplate | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [pendingDelete, setPendingDelete] = useState<ActivityTemplate | null>(null)

  async function action(id: string, type: 'rename' | 'copy' | 'delete', name?: string) {
    try {
      await manage.mutateAsync({ id, action: type, name })
      setRename(null); setPendingDelete(null)
      onMessage(type === 'rename' ? '範本名稱已更新。' : type === 'copy' ? '範本已複製。' : '範本已刪除。')
    } catch { onMessage('目前無法處理活動範本，請稍後再試。') }
  }

  return <section>
    <div className="section-heading settings-section-heading"><div><h2>活動範本</h2><p className="muted">重用球館、方案、場地與排點設定；建立時日期會改為今天。</p></div></div>
    {templates.isLoading ? <div className="centered-state compact">載入活動範本…</div> : templates.isError ? <div className="empty-state compact"><p>目前無法載入活動範本。</p><button className="secondary-button" onClick={() => void templates.refetch()}>重新整理</button></div> : items.length === 0 ? <div className="empty-state compact"><h3>尚未建立活動範本</h3><p>建立活動時勾選「同時儲存為活動範本」即可加入。</p></div> : <div className="template-list">{items.map((template) => {
      const config = template.config_snapshot
      return <article key={template.id}><div className="template-main"><strong>{template.name}</strong><span>{config.custom_title || '未設定活動標題'} · {config.venue.name}</span><small>{config.plans.map((plan) => `方案 ${plan.code}`).join('、')} · {config.initial_court_count} 面場 · {assignLabels[config.assign_mode] ?? config.assign_mode}</small><small>更新於 {new Intl.DateTimeFormat('zh-TW', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(template.updated_at))}</small></div><div className="template-actions"><button className="primary-button" onClick={() => navigate(`/activities/new?template=${template.id}`)}>使用範本</button><button className="text-button" onClick={() => navigate(`/activities/new?editTemplate=${template.id}`)}>編輯內容</button><button className="text-button" onClick={() => { setRename(template); setRenameValue(template.name) }}>重新命名</button><button className="text-button" onClick={() => void action(template.id, 'copy')}>複製</button><button className="text-button danger-text" onClick={() => setPendingDelete(template)}>刪除</button></div></article>
    })}</div>}
    {rename && <div className="panel-backdrop" role="presentation"><section className="confirm-dialog template-rename-dialog" role="dialog" aria-modal="true" aria-labelledby="rename-template-title"><h2 id="rename-template-title">重新命名範本</h2><label>範本名稱<input autoFocus maxLength={50} value={renameValue} onChange={(event) => setRenameValue(event.target.value)} /></label><footer><button className="secondary-button" onClick={() => setRename(null)}>取消</button><button className="primary-button" disabled={!renameValue.trim() || manage.isPending} onClick={() => void action(rename.id, 'rename', renameValue.trim())}>儲存名稱</button></footer></section></div>}
    {pendingDelete && <div className="panel-backdrop" role="presentation"><section className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-template-title"><h2 id="delete-template-title">刪除「{pendingDelete.name}」？</h2><p>刪除後無法再從此範本建立活動；已建立的活動不受影響。</p><footer><button className="secondary-button" onClick={() => setPendingDelete(null)}>返回</button><button className="danger-button" disabled={manage.isPending} onClick={() => void action(pendingDelete.id, 'delete')}>刪除範本</button></footer></section></div>}
  </section>
}
