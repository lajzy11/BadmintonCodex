import { type FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { appConfig } from '../../lib/config'
import { AuthLayout } from './AuthLayout'
import { registerAccount } from './authApi'

export function RegisterPage() {
  const navigate = useNavigate()
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    const form = new FormData(event.currentTarget)
    if (form.get('password') !== form.get('passwordConfirmation')) {
      setError('兩次輸入的密碼不一致。')
      return
    }
    if (appConfig.isDemo) {
      navigate('/activities')
      return
    }
    setIsSubmitting(true)
    try {
      await registerAccount({
        username: String(form.get('username')),
        displayName: String(form.get('displayName')),
        organizationName: String(form.get('organizationName')),
        password: String(form.get('password')),
      })
      navigate('/activities')
    } catch {
      setError('無法建立帳號；請確認帳號名稱尚未使用，稍後再試。')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AuthLayout
      eyebrow="開始使用"
      title="建立團主帳號"
      description="帳號名稱只接受英文字母、數字與底線，建立後請妥善保存密碼。"
      footer={<>已經有帳號？ <Link to="/login">返回登入</Link></>}
    >
      <form className="form-stack" onSubmit={handleSubmit}>
        <label>帳號名稱<span className="required-mark" aria-hidden="true">*</span><input name="username" required pattern="[A-Za-z0-9_]{4,30}" minLength={4} maxLength={30} placeholder="4–30 個字元，限英文、數字與底線" /></label>
        <label>顯示名稱<span className="required-mark" aria-hidden="true">*</span><input name="displayName" required maxLength={40} placeholder="例如：小羽" /></label>
        <label>球團名稱<span className="required-mark" aria-hidden="true">*</span><input name="organizationName" required maxLength={40} placeholder="例如：星期三羽球團" /></label>
        <label>密碼<span className="required-mark" aria-hidden="true">*</span><input name="password" type="password" required minLength={8} maxLength={64} pattern="(?=.*[A-Za-z])(?=.*[0-9]).{8,64}" autoComplete="new-password" placeholder="8–64 個字元，至少一個英文字母與數字" /></label>
        <label>確認密碼<span className="required-mark" aria-hidden="true">*</span><input name="passwordConfirmation" type="password" required minLength={8} maxLength={64} autoComplete="new-password" placeholder="再次輸入密碼" /></label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="primary-button full-width" type="submit" disabled={isSubmitting}>{isSubmitting ? '建立中…' : '建立帳號'}</button>
      </form>
    </AuthLayout>
  )
}
