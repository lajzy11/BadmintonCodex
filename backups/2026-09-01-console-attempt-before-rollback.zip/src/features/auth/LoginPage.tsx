import { type FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { appConfig } from '../../lib/config'
import { AuthLayout } from './AuthLayout'
import { loginWithUsername } from './authApi'

export function LoginPage() {
  const navigate = useNavigate()
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    const form = new FormData(event.currentTarget)
    if (appConfig.isDemo) {
      navigate('/activities')
      return
    }
    setIsSubmitting(true)
    try {
      await loginWithUsername(String(form.get('username')), String(form.get('password')))
      navigate('/activities')
    } catch {
      setError('帳號或密碼錯誤，請再試一次。')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AuthLayout
      eyebrow="歡迎回來"
      title="登入團主帳號"
      description="使用你建立的帳號名稱與密碼。"
      footer={<>還沒有帳號？ <Link to="/register">建立帳號</Link></>}
    >
      <form className="form-stack" onSubmit={handleSubmit}>
        <label>
          帳號名稱<span className="required-mark" aria-hidden="true">*</span>
          <input name="username" autoComplete="username" required pattern="[A-Za-z0-9_]{4,30}" minLength={4} maxLength={30} placeholder="輸入帳號名稱" />
        </label>
        <label>
          密碼<span className="required-mark" aria-hidden="true">*</span>
          <input name="password" type="password" autoComplete="current-password" required minLength={8} maxLength={64} placeholder="輸入密碼" />
        </label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="primary-button full-width" type="submit" disabled={isSubmitting}>{isSubmitting ? '登入中…' : '登入'}</button>
        <button className="text-button" type="button" disabled>忘記密碼（上線功能）</button>
      </form>
    </AuthLayout>
  )
}
