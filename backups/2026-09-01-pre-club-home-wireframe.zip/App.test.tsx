import { fireEvent, render, screen } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { MemoryRouter } from 'react-router-dom'
import { expect, test } from 'vitest'
import { App } from './App'
import { AuthProvider } from '../features/auth/AuthProvider'

test('shows the activity center and responsive shell navigation', async () => {
  const { container } = render(
    <QueryClientProvider client={new QueryClient()}>
      <MemoryRouter initialEntries={['/activities']}>
        <AuthProvider><App /></AuthProvider>
      </MemoryRouter>
    </QueryClientProvider>,
  )
  expect(await screen.findByText('羽你有約')).toBeInTheDocument()
  expect(await screen.findAllByText('週日早場零打')).not.toHaveLength(0)
  expect(screen.getByText('小羽')).toBeInTheDocument()
  expect(screen.getByText('badminton_owner')).toBeInTheDocument()
  expect(screen.getByText('3 / 3 未封存活動')).toBeInTheDocument()
  expect(screen.getByRole('button', { name: /建立新活動/ })).toBeDisabled()
  expect(screen.getAllByLabelText('更多活動操作')).not.toHaveLength(0)

  fireEvent.click(screen.getByRole('tab', { name: /已封存 1/ }))
  expect(screen.getByText('八月零打')).toBeInTheDocument()
  expect(container.querySelector('.club-activity-list')).not.toHaveTextContent('週日早場零打')

  fireEvent.click(screen.getByRole('button', { name: '收合選單' }))
  expect(screen.getByRole('button', { name: '展開選單' })).toBeInTheDocument()

  expect(container.querySelector('.club-identity')).toHaveAttribute('href', '/activities')
  const allActivities = screen.getByRole('link', { name: /查看全部活動/ })
  const createActivity = screen.getByRole('link', { name: /建立活動/ })
  expect(allActivities.compareDocumentPosition(createActivity) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()

  const mobileHeader = container.querySelector('.mobile-shell-bar')
  expect(mobileHeader?.querySelector('.sidebar-logo')).toBeNull()
  expect(mobileHeader?.querySelector('[aria-label="帳號選單"]')).toBeNull()
})
