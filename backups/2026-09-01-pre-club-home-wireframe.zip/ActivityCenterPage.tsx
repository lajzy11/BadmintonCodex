import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { MaterialIcon } from '../../app/MaterialIcon'
import { type ActivityStatus, type ActivitySummary, useActivityCenter, useManageActivity } from './activityCenterApi'

type Filter = 'all' | 'unfinished' | 'ended' | 'draft' | 'archived'

const statusLabels: Record<ActivityStatus, string> = {
  draft: '草稿', scheduled: '即將開始', in_progress: '進行中', ended: '已結束', archived: '已封存',
}

const emptyMessages: Record<Filter, [string, string]> = {
  all: ['還沒有活動', '建立第一個活動，開始管理零打。'],
  unfinished: ['目前沒有未結束活動', '進行中或即將開始的活動會顯示在這裡。'],
  ended: ['目前沒有已結束活動', '結束後的活動會保留在這裡，方便複製或封存。'],
  draft: ['目前沒有活動草稿', '尚未完成的活動草稿會顯示在這裡。'],
  archived: ['目前沒有已封存活動', '封存後的活動不會占用活動名額。'],
}

function matchesFilter(activity: ActivitySummary, filter: Filter) {
  if (filter === 'all') return true
  if (filter === 'unfinished') return activity.status === 'scheduled' || activity.status === 'in_progress'
  return activity.status === filter
}

function sortActivities(activities: ActivitySummary[], filter: Filter) {
  const copy = [...activities]
  if (filter === 'ended') return copy.sort((a, b) => b.activityDate.localeCompare(a.activityDate))
  if (filter === 'archived') return copy.sort((a, b) => (b.archivedAt ?? '').localeCompare(a.archivedAt ?? ''))
  if (filter === 'unfinished' || filter === 'draft') return copy.sort((a, b) => a.activityDate.localeCompare(b.activityDate))
  const rank: Record<ActivityStatus, number> = { in_progress: 0, scheduled: 1, draft: 2, ended: 3, archived: 4 }
  return copy.sort((a, b) => rank[a.status] - rank[b.status] || (rank[a.status] <= 2 ? a.activityDate.localeCompare(b.activityDate) : b.activityDate.localeCompare(a.activityDate)))
}

function primaryAction(activity: ActivitySummary) {
  if (activity.status === 'draft') return '繼續編輯'
  if (activity.status === 'archived') return '查看活動'
  return '進入活動'
}

export function ActivityCenterPage() {
  const activityCenter = useActivityCenter()
  const manageActivity = useManageActivity()
  const navigate = useNavigate()
  const [filter, setFilter] = useState<Filter>('all')
  const [actionError, setActionError] = useState('')

  const data = activityCenter.data
  const counts = useMemo(() => {
    const activities = data?.activities ?? []
    return {
      all: activities.length,
      unfinished: activities.filter((activity) => matchesFilter(activity, 'unfinished')).length,
      ended: activities.filter((activity) => activity.status === 'ended').length,
      draft: activities.filter((activity) => activity.status === 'draft').length,
      archived: activities.filter((activity) => activity.status === 'archived').length,
    }
  }, [data?.activities])
  const visibleActivities = useMemo(() => sortActivities((data?.activities ?? []).filter((activity) => matchesFilter(activity, filter)), filter), [data?.activities, filter])

  if (activityCenter.isLoading) return <div className="centered-state">載入球團資料…</div>
  if (activityCenter.isError || !data) return <div className="centered-state"><p>目前無法載入球團資料。</p><button className="secondary-button" onClick={() => activityCenter.refetch()}>重新整理</button></div>

  const atLimit = data.unarchivedCount >= 3
  async function runAction(activity: ActivitySummary, action: 'archive' | 'unarchive' | 'delete') {
    setActionError('')
    if (action === 'delete' && !window.confirm(`確定要刪除「${activity.title || activity.venue}」嗎？此操作無法復原。`)) return
    try { await manageActivity.mutateAsync({ activityId: activity.id, action }) }
    catch { setActionError(action === 'unarchive' ? '無法取消封存；請確認未封存活動尚未達 3 筆。' : '活動操作失敗，請稍後再試。') }
  }

  return <div className="activity-center-page club-home-page">
    <section className="club-home-hero">
      <div><p className="eyebrow">球團首頁</p><h1>{data.organizationName}</h1><p>管理活動與近期開團安排。</p></div>
      <div className="club-home-cta">
        <button type="button" className="secondary-button icon-text-button" disabled={atLimit} onClick={() => navigate('/club-settings?section=templates')}><MaterialIcon name="copy" />從範本建立</button>
        <button type="button" className="primary-button icon-text-button" disabled={atLimit} onClick={() => navigate('/activities/new')}><MaterialIcon name="add" />建立新活動</button>
      </div>
    </section>

    <section className={atLimit ? 'activity-usage at-limit' : 'activity-usage'} aria-label="未封存活動使用量">
      <div><span>活動使用量</span><strong>{data.unarchivedCount} / 3 未封存活動</strong></div>
      <div className="usage-track"><span style={{ width: `${Math.min(100, data.unarchivedCount / 3 * 100)}%` }} /></div>
      <p>{atLimit ? '已達活動上限，封存已結束活動或刪除草稿後即可建立新活動。' : '草稿、未結束及已結束活動都會占用名額；封存後即可釋出。'}</p>
      {atLimit && counts.ended > 0 && <button type="button" className="text-button" onClick={() => setFilter('ended')}>查看可封存活動</button>}
    </section>

    <section className="club-activity-section">
      <header className="club-activity-heading"><div><h2>活動</h2><span>依狀態與活動日期排序</span></div></header>
      <div className="club-activity-filters" role="tablist" aria-label="活動狀態">
        {([['all', '全部'], ['unfinished', '未結束'], ['ended', '已結束'], ['draft', '草稿'], ['archived', '已封存']] as Array<[Filter, string]>).map(([value, label]) => <button type="button" role="tab" aria-selected={filter === value} className={filter === value ? 'active' : ''} onClick={() => setFilter(value)} key={value}>{label} <span>{counts[value]}</span></button>)}
      </div>
      {actionError && <div className="validation-box" role="alert"><p>{actionError}</p></div>}

      {visibleActivities.length === 0 ? <div className="club-activity-empty"><h3>{emptyMessages[filter][0]}</h3><p>{emptyMessages[filter][1]}</p>{filter === 'all' && !atLimit && <Link className="activity-create-button" to="/activities/new">建立新活動</Link>}</div> : <div className="club-activity-list">{visibleActivities.map((activity) => <article className={`club-activity-row status-${activity.status}`} key={activity.id}>
        <div className="club-activity-date"><strong>{activity.date}</strong><span>{activity.weekday}</span></div>
        <div className="club-activity-main"><div><h3>{activity.title || activity.venue}</h3><span className={`status status-${activity.status}`}>{statusLabels[activity.status]}</span></div><p>{activity.time} · {activity.venue}{activity.location ? ` · ${activity.location}` : ''}</p></div>
        <div className="club-activity-count"><span>名單</span><strong>{activity.members}{activity.capacity ? ` / ${activity.capacity}` : ''}</strong></div>
        <div className="club-activity-actions"><Link className="activity-enter-link" to={`/activities/${activity.id}`}>{primaryAction(activity)}</Link><details className="activity-more-menu"><summary aria-label="更多活動操作"><MaterialIcon name="moreVert" /></summary><div>
          {activity.status !== 'draft' && <Link to={`/activities/new?copy=${activity.id}`}>複製活動</Link>}
          {activity.status === 'ended' && <button type="button" onClick={() => runAction(activity, 'archive')}>封存活動</button>}
          {activity.status === 'archived' && <button type="button" disabled={atLimit} onClick={() => runAction(activity, 'unarchive')}>取消封存</button>}
          {(activity.status === 'draft' || activity.status === 'archived') && <button type="button" className="danger-text" onClick={() => runAction(activity, 'delete')}>刪除活動</button>}
        </div></details></div>
      </article>)}</div>}
    </section>
  </div>
}
