import type { WorkspacePlan } from './activityWorkspaceApi'

export type MemberFilters = {
  search: string
  status: string
  plan: string
  checkin: string
  payment: string
  gender: string
  attendance: string
  level: string
  timeEligibility: string
  sort: string
  view: 'card' | 'table'
}

export function MemberFilterBar({ filters, plans, onChange }: { filters: MemberFilters; plans: WorkspacePlan[]; onChange: (next: MemberFilters) => void }) {
  const patch = (values: Partial<MemberFilters>) => onChange({ ...filters, ...values })
  const hasAdvancedFilters = Boolean(filters.gender || filters.attendance || filters.level || filters.timeEligibility)

  return <div className={`member-filter-bar ${filters.view}`}>
    <div className="member-filter-heading">
      <div className="member-status-tabs"><button className={filters.status === 'active' ? 'active' : ''} onClick={() => patch({ status: 'active' })}>有效名單</button><button className={filters.status === 'cancelled' ? 'active' : ''} onClick={() => patch({ status: 'cancelled' })}>已取消</button></div>
      <div className="member-view-switch" aria-label="名單顯示模式"><button className={filters.view === 'card' ? 'active' : ''} onClick={() => patch({ view: 'card' })}>卡片</button><button className={filters.view === 'table' ? 'active' : ''} onClick={() => patch({ view: 'table' })}>表格</button></div>
    </div>
    <div className="member-filter-controls">
      <input aria-label="搜尋球友姓名" placeholder="搜尋姓名" value={filters.search} onChange={(event) => patch({ search: event.target.value })} />
      <select aria-label="篩選方案" value={filters.plan} onChange={(event) => patch({ plan: event.target.value })}><option value="">全部方案</option>{plans.map((plan) => <option key={plan.id} value={plan.id}>方案 {plan.code}</option>)}</select>
      <select aria-label="篩選報到狀態" value={filters.checkin} onChange={(event) => patch({ checkin: event.target.value })}><option value="">全部報到狀態</option><option value="not_arrived">尚未報到</option><option value="checked_in">已報到</option></select>
      <select aria-label="篩選付款狀態" value={filters.payment} onChange={(event) => patch({ payment: event.target.value })}><option value="">全部付款狀態</option><option value="unpaid">尚未付款</option><option value="paid">已付款</option></select>
      <select aria-label="名單排序" value={filters.sort} onChange={(event) => patch({ sort: event.target.value })}><option value="source">原始順序</option><option value="name">姓名</option><option value="plan">方案</option><option value="level">級數</option><option value="checkin">報到狀態</option><option value="payment">付款狀態</option></select>
    </div>
    <details className="member-advanced-filters" open={hasAdvancedFilters || undefined}>
      <summary>更多篩選{hasAdvancedFilters && <span>已套用</span>}</summary>
      <div>
        <select aria-label="篩選級數" value={filters.level} onChange={(event) => patch({ level: event.target.value })}><option value="">全部級數</option>{Array.from({ length: 18 }, (_, index) => index + 1).map((level) => <option key={level} value={level}>Lv.{level}</option>)}</select>
        <select aria-label="篩選性別" value={filters.gender} onChange={(event) => patch({ gender: event.target.value })}><option value="">全部性別</option><option value="M">男</option><option value="F">女</option><option value="unspecified">未填寫</option></select>
        <select aria-label="篩選在場狀態" value={filters.attendance} onChange={(event) => patch({ attendance: event.target.value })}><option value="">全部在場狀態</option><option value="idle">等待</option><option value="playing">比賽中</option><option value="rest">休息</option></select>
        <select aria-label="篩選方案時間狀態" value={filters.timeEligibility} onChange={(event) => patch({ timeEligibility: event.target.value })}><option value="">全部方案時間</option><option value="not_started">尚未到方案時間</option><option value="current">目前有效</option><option value="expired">方案時間已到</option></select>
        {hasAdvancedFilters && <button className="text-button" onClick={() => patch({ level: '', gender: '', attendance: '', timeEligibility: '' })}>清除進階篩選</button>}
      </div>
    </details>
  </div>
}
